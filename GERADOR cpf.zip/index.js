let arr = []

let mult = 0, armazenaMult = [], somaTotal = 0, qtdCPF = 0
let digitoVerificador = 0, resto = 0, numAleatorio = 0
const DIV = 11

const getbottom = document.querySelector('#bottom')
let creatDivCpf = document.createElement('p')

function geradorDeCPF () {
    let contador = 0
    for(let x = 0; x < qtdCPF; x++){
        
        creatDivCpf = document.createElement('p')
        creatDivCpf.setAttribute('class', 'cpfs') 
        getbottom.appendChild(creatDivCpf)
        principal ()
        
        let valores = arr.join('')
        if(valores >= 3){
            console.log(valores[3])
            arr.splice(3, 0, ".")
        }
        if(valores >= 6){
            console.log(valores[3])
            arr.splice(7, 0, ".")
        }
        
        if(valores >= 9){
            console.log(valores[3])
            arr.splice(11, 0, "-")
        }
        
        const textCPF = document.createTextNode(arr.join(''))
        creatDivCpf.appendChild(textCPF)
        console.log(arr.join('')) // remover
        
        console.log(arr)
        contador++
        if(contador % 2 === 0){
            creatDivCpf.classList.add('color2')
        }
    }
}

function principal () {

    function numerosAleatorios () {
        zerarValores()
        
        let min = 0, max = 9
        max = max +  1
        for(i = 0; i < 9; i++){
            numAleatorio = Math.floor(Math.random() * (max-min)) + min
            arr.push(numAleatorio)
            // console.log(arr) 
        }
    }

function primeiroCalc () {
    numerosAleatorios ()

    mult = 10
    multiplicador ()
    somar()
    digVerify()
}

primeiroCalc()

function segundoCalc() {
    mult = 11
    multiplicador ()
    somar()
    digVerify()
}

segundoCalc()

}

// Funções secundarias de calculos

function zerarValores(){
    mult = 0
    armazenaMult = [] 
    somaTotal = 0
    digitoVerificador = 0
    resto = 0
    numAleatorio = 0
    arr = []
}
function multiplicador (){
    armazenaMult = arr.map( (elem) => {
        elem *= mult
        mult--
        return elem
    } )
}

function somar(){
    armazenaMult.reduce( (acumulador, valorAtual)=> {
        somaTotal = acumulador + valorAtual
        return somaTotal
    }, )
}
function digVerify(){
    resto = somaTotal%DIV

    if(resto >= 2){
        digitoVerificador = DIV-resto
        arr.push(digitoVerificador)
    }else{
        digitoVerificador = 0
        arr.push(digitoVerificador)
    }
}