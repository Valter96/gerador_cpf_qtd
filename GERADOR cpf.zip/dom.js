// Capturando Valores Input
const getInput = document.querySelector('#qtd')
const getBtn = document.querySelector('#botao')
const getBtnRem = document.querySelector('#remover')
const getP = document.querySelectorAll('p')

//const removeDivCpf = document.querySelectorAll('#bottom > p')

let valorInput

const removeCPF = () => {
    const getP = document.querySelectorAll('.cpfs')
    
    for(n of getP){
        console.log(n.remove())
    }  
}

getBtn.addEventListener('click', () =>{
    removeCPF()
    valorInput = getInput.value
    valorInput = Number(valorInput)
    function valueIsNaN(v) {
        return v !== v;
    }

    if(valorInput === 0){
        const getP = document.querySelectorAll('.cpfs')

        getP[1].innerHTML = 'Valor maior que 0 meu fi!'
        limparReclam()
        
        for(n of getP){
            console.log(n.remove())
        } 
    }else if(valorInput == ''){
        const getP = document.querySelectorAll('.cpfs')

        getP[1].innerHTML = 'Insira um valor meu fi!'
        limparReclam()

        for(n of getP){
            console.log(n.remove())
        } 
        
    }else if(valueIsNaN(valorInput) === false){
        qtdCPF = valorInput
        getInput.value = ''
    }else{
        getInput.value = ''
        getP[1].innerHTML = 'Digite apenas número meu fi!'
        limparReclam()
        removeCPF()
    }
    
    geradorDeCPF ()
})

function limparReclam(){
    setTimeout( ()=> {
        getP[1].innerHTML = ''
    }, 2000)
}


getBtnRem.addEventListener('click', removeCPF)


